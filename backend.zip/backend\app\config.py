from functools import lru_cache
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_name: str = "Ardvmeetinghub"
    environment: str = "development"
    database_url: str = "sqlite:///./ardvmeetinghub.db"
    jwt_secret_key: str = "change-me-in-production"
    jwt_algorithm: str = "HS256"
    access_token_expire_minutes: int = 60 * 24
    frontend_origin: str = "http://localhost:5173"

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        if self.environment == "production" and self.jwt_secret_key == "change-me-in-production":
            raise ValueError(
                "JWT_SECRET_KEY must be set to a secure random value in production. "
                "Set the JWT_SECRET_KEY environment variable."
            )


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
