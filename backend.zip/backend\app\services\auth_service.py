from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session

from app.database import get_db
from app.models.user import User
from app.schemas.user import UserCreate
from app.utils.security import create_access_token, decode_token, hash_password, verify_password

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login")

AVATAR_COLORS = ["#2563eb", "#7c3aed", "#db2777", "#0891b2", "#16a34a", "#ea580c"]


def get_user_by_email(db: Session, email: str) -> User | None:
    return db.query(User).filter(User.email == email.lower()).first()


def register_user(db: Session, payload: UserCreate) -> User:
    if get_user_by_email(db, payload.email):
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Email is already registered")
    color = AVATAR_COLORS[sum(ord(ch) for ch in payload.email) % len(AVATAR_COLORS)]
    user = User(
        name=payload.name.strip(),
        email=payload.email.lower(),
        hashed_password=hash_password(payload.password),
        avatar_color=color,
    )
    db.add(user)
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Email is already registered")
    db.refresh(user)
    return user


def update_user_profile(db: Session, user: User, name: str | None = None, email: str | None = None, password: str | None = None, profile_pic: str | None = None) -> User:
    if email and email.lower() != user.email:
        if get_user_by_email(db, email):
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Email is already registered")
        user.email = email.lower()
        user.avatar_color = AVATAR_COLORS[sum(ord(ch) for ch in user.email) % len(AVATAR_COLORS)]
        
    if name:
        user.name = name.strip()
        
    if password:
        user.hashed_password = hash_password(password)
        
    if profile_pic is not None:
        user.profile_pic = profile_pic
        
    try:
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Email is already registered")
        
    db.refresh(user)
    return user


def reset_password(db: Session, email: str, name: str, new_password: str) -> bool:
    user = get_user_by_email(db, email)
    if not user:
        return False
    # Verify the name matches (case-insensitive and ignoring extra spaces)
    db_name = " ".join(user.name.split()).lower()
    input_name = " ".join(name.split()).lower()
    if db_name != input_name:
        return False
        
    user.hashed_password = hash_password(new_password)
    db.commit()
    return True


def authenticate_user(db: Session, email: str, password: str) -> User | None:
    user = get_user_by_email(db, email)
    if not user or not verify_password(password, user.hashed_password):
        return None
    return user


def issue_token(user: User) -> str:
    return create_access_token(subject=str(user.id), extra={"email": user.email})


def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    credentials_error = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )
    payload = decode_token(token)
    if not payload or not payload.get("sub"):
        raise credentials_error
    user = db.get(User, int(payload["sub"]))
    if not user:
        raise credentials_error
    return user
